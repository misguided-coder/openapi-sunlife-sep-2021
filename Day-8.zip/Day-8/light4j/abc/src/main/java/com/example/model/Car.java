package com.example.model;

import java.util.Arrays;
import java.util.Objects;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Car  {

    private Integer vin;
    private String model;
    private String make;
    private java.lang.Double price;
    
    
    public enum ColorEnum {
        
        @JsonProperty("Red")
        RED ("Red"), 
        
        @JsonProperty("White")
        WHITE ("White"), 
        
        @JsonProperty("Black")
        BLACK ("Black"), 
        
        @JsonProperty("Yellow")
        YELLOW ("Yellow"); 
        

        private final String value;

        ColorEnum(String value) {
            this.value = value;
        }

        @Override
        public String toString() {
            return String.valueOf(value);
        }

        public static ColorEnum fromValue(String text) {
            for (ColorEnum b : ColorEnum.values()) {
                if (String.valueOf(b.value).equals(text)) {
                return b;
                }
            }
            return null;
        }
    }

    private ColorEnum color;

    

    public Car () {
    }

    @JsonProperty("vin")
    public Integer getVin() {
        return vin;
    }

    public void setVin(Integer vin) {
        this.vin = vin;
    }

    @JsonProperty("model")
    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    @JsonProperty("make")
    public String getMake() {
        return make;
    }

    public void setMake(String make) {
        this.make = make;
    }

    @JsonProperty("price")
    public java.lang.Double getPrice() {
        return price;
    }

    public void setPrice(java.lang.Double price) {
        this.price = price;
    }

    @JsonProperty("color")
    public ColorEnum getColor() {
        return color;
    }

    public void setColor(ColorEnum color) {
        this.color = color;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }

        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        Car Car = (Car) o;

        return Objects.equals(vin, Car.vin) &&
               Objects.equals(model, Car.model) &&
               Objects.equals(make, Car.make) &&
               Objects.equals(price, Car.price) &&
               Objects.equals(color, Car.color);
    }

    @Override
    public int hashCode() {
        return Objects.hash(vin, model, make, price, color);
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("class Car {\n");
        sb.append("    vin: ").append(toIndentedString(vin)).append("\n");        sb.append("    model: ").append(toIndentedString(model)).append("\n");        sb.append("    make: ").append(toIndentedString(make)).append("\n");        sb.append("    price: ").append(toIndentedString(price)).append("\n");        sb.append("    color: ").append(toIndentedString(color)).append("\n");
        sb.append("}");
        return sb.toString();
    }

    /**
     * Convert the given object to string with each line indented by 4 spaces
     * (except the first line).
     */
    private String toIndentedString(Object o) {
        if (o == null) {
            return "null";
        }
        return o.toString().replace("\n", "\n    ");
    }
}
