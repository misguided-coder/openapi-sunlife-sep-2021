import java.net.http.*;
import java.net.*;

public class APIClient {
	
	public static void main(String[] args) throws Exception {

		 HttpRequest request = HttpRequest.newBuilder()
		.uri(URI.create("https://currency-exchange.p.rapidapi.com/exchange?to=INR&from=USD&q=1"))
		.header("x-rapidapi-host", "currency-exchange.p.rapidapi.com")
		.header("x-rapidapi-key", "6c455f075cmshffa7e2f788a3b49p13eb76jsn0927bfeb2464")
		.method("GET", HttpRequest.BodyPublishers.noBody())
		.build();
		HttpResponse<String> response = HttpClient.newHttpClient().send(request, HttpResponse.BodyHandlers.ofString());
		System.out.println(response.body());

	}

}