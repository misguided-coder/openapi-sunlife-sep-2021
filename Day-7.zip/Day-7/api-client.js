const request = require('request');

const options = {
  method: 'GET',
  url: 'https://currency-exchange.p.rapidapi.com/exchange',
  qs: {to: 'INR', from: 'USD', q: '1000'},
  headers: {
    'x-rapidapi-host': 'currency-exchange.p.rapidapi.com',
    'x-rapidapi-key': '6c455f075cmshffa7e2f788a3b49p13eb76jsn0927bfeb2464',
    useQueryString: true
  }
};

request(options, function (error, response, body) {
	if (error) throw new Error(error);
	console.log("Response Received ==========================>>> ");
	console.log(body);
});
